package edu.kh.jdbc.run;

import edu.kh.jdbc.main.view.MainView;

public class ProjectRun {
	public static void main(String[] args) {
		MainView mainView = new MainView();
		mainView.displayMenu();
		
	}
	
}
